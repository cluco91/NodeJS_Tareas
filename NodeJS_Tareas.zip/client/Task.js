"use strict";
var Task = (function () {
    function Task() {
    }
    return Task;
}());
exports.Task = Task;
//# sourceMappingURL=Task.js.map