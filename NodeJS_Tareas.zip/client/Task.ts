export class Task{
    title: string;
    isDone: boolean;
}